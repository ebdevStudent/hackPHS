import argparse
import csv
import json
import os
import secrets
import time
from pathlib import Path

import uvicorn

from .api import create_app
from .bridge import SerialBridge
from .engine import Engine
from .fixtures import generate
from .protocol import BridgeCore


def main():
    parser = argparse.ArgumentParser(description='Ball Drone software demo; no physical transmitter output')
    sub = parser.add_subparsers(dest='command', required=True)
    serve = sub.add_parser('serve')
    serve.add_argument('--host', default='127.0.0.1')
    serve.add_argument('--port', type=int, default=8080)
    serve.add_argument('--data', default=os.environ.get('BALL_DATA_DIR', 'runs'))
    serve.add_argument('--serial', help='Explicit device opt-in; scaffold internal state only')
    serve.add_argument('--recorded', help='Start disabled on a video file')
    fixtures = sub.add_parser('fixtures')
    fixtures.add_argument('--output', default='runs/fixtures')
    fixtures.add_argument('--frames', type=int, default=160)
    replay = sub.add_parser('replay')
    replay.add_argument('session')
    replay.add_argument('--output', default='runs/replay.json')
    sub.add_parser('bridge-check')
    card = sub.add_parser('connection-card')
    card.add_argument('--url', required=True)
    card.add_argument('--network', default='Shared network')
    card.add_argument('--output', default='runs/connection-card')
    args = parser.parse_args()
    if args.command == 'serve':
        token = os.environ.get('BALL_OPERATOR_TOKEN') or secrets.token_urlsafe(24)
        Path(args.data).mkdir(parents=True, exist_ok=True)
        token_path = Path(args.data) / 'operator-token'
        fd = os.open(token_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w') as f: f.write(token + '\n')
        print(f'Visitor URL: http://{args.host}:{args.port}/', flush=True)
        print(f'Operator token saved to {token_path.resolve()} (local, private). Startup: MANUAL.', flush=True)
        source = {'kind': 'recorded', 'path': args.recorded} if args.recorded else None
        bridge = SerialBridge(args.serial) if args.serial else None
        engine = Engine(args.data, bridge=bridge, source=source)
        class DemoServer(uvicorn.Server):
            def handle_exit(self, sig, frame):
                engine.assist(False)
                engine.running = False
                super().handle_exit(sig, frame)
        server = DemoServer(uvicorn.Config(create_app(engine, token), host=args.host, port=args.port,
                                          log_level='warning', timeout_graceful_shutdown=2))
        server.run()
    elif args.command == 'fixtures': generate(args.output, args.frames)
    elif args.command == 'bridge-check':
        core = BridgeCore()
        print(core.receive('HELLO 1 demo\n', 0), end='')
        print(core.receive('CMD 1 demo 1 1 200\n', .1), end='')
        core.tick(.351)
        assert core.yaw == 0 and core.fault == 'WATCHDOG'
        print('WATCHDOG: neutral; no physical output')
    elif args.command == 'replay':
        root = Path(args.session)
        samples = []
        with (root / 'samples.csv').open() as f:
            for row in csv.DictReader(f):
                detection = None
                if row['x']:
                    detection = {'x': float(row['x']), 'y': float(row['y']), 'error': float(row['error']), 'quality': float(row['quality'])}
                samples.append({'t': float(row['t']), 'state': row['state'], 'yaw': int(row['yaw']), 'detection': detection})
        events = [json.loads(line) for line in (root / 'events.jsonl').read_text().splitlines()]
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps({'label': 'REPLAY / no bridge output', 'samples': samples, 'events': events}))
        print(output.resolve())
    elif args.command == 'connection-card':
        import qrcode
        from urllib.parse import urlparse
        if urlparse(args.url).scheme not in ['http', 'https']: parser.error('Provide the active HTTP visitor URL')
        output = Path(args.output)
        output.mkdir(parents=True, exist_ok=True)
        qrcode.make(args.url).save(output / 'visitor-qr.png')
        (output / 'visitor.txt').write_text(f'Ball Drone visitor access\nNetwork: {args.network}\nURL: {args.url}\nNo operator credentials required.\n')
        print(output.resolve())


if __name__ == '__main__': main()
