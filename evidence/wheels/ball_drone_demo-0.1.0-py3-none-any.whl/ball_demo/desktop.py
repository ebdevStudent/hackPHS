"""Native operator workstation. No HTML/WebView; the HTTP server remains for visitors."""
import argparse
import json
import sys
import time
import shutil
import os
import tempfile
import multiprocessing
import math
from collections import deque
from pathlib import Path
from urllib.parse import urlparse

from PySide6.QtCore import Qt, QTimer, QUrl, Signal, QStandardPaths, QRectF, QPointF, QEventLoop, QLibraryInfo, QFileInfo, QCoreApplication
from PySide6.QtGui import QAction, QColor, QDesktopServices, QPainter, QPen, QPixmap, QFontDatabase, QIcon
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QDockWidget, QFormLayout, QDialog, QDialogButtonBox, QLineEdit,
    QFileDialog, QMessageBox, QDoubleSpinBox, QSpinBox, QTreeWidget, QTreeWidgetItem,
    QTabWidget, QSplitter, QSlider, QGroupBox, QToolBar, QStyle,
)

from .sources import SCENARIOS


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def validate_detection(value):
    if value is None: return
    if not isinstance(value, dict): raise ValueError('Invalid detection')
    for key in ('x', 'y', 'area', 'error', 'quality'):
        if key in value and not finite_number(value[key]): raise ValueError('Invalid detection measurement')
    if 'error' in value and not -1 <= value['error'] <= 1: raise ValueError('Invalid detection error')
    if 'quality' in value and not 0 <= value['quality'] <= 1: raise ValueError('Invalid detection quality')
    if 'area' in value and value['area'] < 0: raise ValueError('Invalid detection area')
    if 'bbox' in value:
        box = value['bbox']
        if (not isinstance(box, (list, tuple)) or len(box) != 4 or not all(finite_number(n) for n in box)
            or min(box[2:]) <= 0): raise ValueError('Invalid detection bounds')


def validate_snapshot(value):
    required = {'state', 'enabled', 'yaw', 'ack_yaw', 'source', 'source_label',
                'settings', 'session', 'bridge', 'bridge_fault', 'fault', 'detection',
                'frame_age_ms', 'ack_age_ms', 'processing_ms', 'frames'}
    if not isinstance(value, dict) or not required.issubset(value):
        raise ValueError('Incomplete state snapshot')
    if value['state'] not in ('MANUAL', 'SEARCHING', 'LOCKED', 'FAULT') or type(value['enabled']) is not bool:
        raise ValueError('Invalid controller state')
    for key in ('yaw', 'ack_yaw'):
        if type(value[key]) is not int or abs(value[key]) > 1000: raise ValueError('Invalid yaw')
    if not isinstance(value['settings'], dict) or not isinstance(value['source'], dict):
        raise ValueError('Invalid source/settings')
    if value['source'].get('kind') not in ('synthetic', 'recorded', 'camera'):
        raise ValueError('Unknown source kind')
    if any(not finite_number(number) for number in value['settings'].values()):
        raise ValueError('Invalid settings measurement')
    if 'scenario' in value['source'] and not isinstance(value['source']['scenario'], str):
        raise ValueError('Invalid source scenario')
    if type(value['frames']) is not int or value['frames'] < 0: raise ValueError('Invalid frame count')
    if value['fault'] is not None and not isinstance(value['fault'], str): raise ValueError('Invalid fault label')
    if ((value['state'] in ('MANUAL', 'FAULT') and value['enabled']) or
        (value['state'] in ('SEARCHING', 'LOCKED') and not value['enabled']) or
        (value['state'] != 'LOCKED' and value['yaw'] != 0)):
        raise ValueError('Inconsistent controller state')
    validate_detection(value['detection'])
    for key in ('frame_age_ms', 'ack_age_ms', 'processing_ms'):
        number = value[key]
        if number is not None and (type(number) not in (int, float) or not math.isfinite(number) or number < 0):
            raise ValueError('Invalid timing measurement')
    for key in ('source_label', 'session', 'bridge', 'bridge_fault'):
        if not isinstance(value[key], str): raise ValueError('Invalid state label')


def validate_trace(value):
    if not isinstance(value, dict) or not isinstance(value.get('samples'), list) or not 1 <= len(value['samples']) <= 100000:
        raise ValueError('Expected a nonempty fixture sample list')
    settings = value.get('settings', {})
    if not isinstance(settings, dict): raise ValueError('Invalid trace settings')
    width, height, hz = settings.get('width', 640), settings.get('height', 480), settings.get('processing_hz', 20)
    if type(width) is not int or type(height) is not int or min(width, height) < 1 or max(width, height) > 4096 or width * height > 4000000:
        raise ValueError('Invalid trace dimensions')
    if type(hz) not in (int, float) or not math.isfinite(hz) or not 0 < hz <= 240:
        raise ValueError('Invalid trace processing rate')
    def finite(number): return type(number) in (int, float) and math.isfinite(number)
    previous = -1
    for sample in value['samples']:
        if not isinstance(sample, dict) or not finite(sample.get('t')) or sample['t'] < 0 or sample['t'] < previous:
            raise ValueError('Invalid or unordered trace timestamp')
        previous = sample['t']
        if sample.get('state') not in ('MANUAL', 'SEARCHING', 'LOCKED', 'FAULT') or type(sample.get('yaw')) is not int or abs(sample['yaw']) > 1000:
            raise ValueError('Invalid trace state/yaw')
        if sample['state'] != 'LOCKED' and sample['yaw'] != 0: raise ValueError('Inconsistent trace state/yaw')
        truth, detection = sample.get('truth', {}), sample.get('detection')
        if not isinstance(truth, dict) or (detection is not None and not isinstance(detection, dict)):
            raise ValueError('Invalid trace geometry')
        if 'visible' in truth and type(truth['visible']) is not bool: raise ValueError('Invalid target visibility')
        if truth.get('visible') and not all(finite(truth.get(key)) for key in ('x', 'y', 'radius')):
            raise ValueError('Invalid visible target')
        if truth.get('visible') and truth['radius'] <= 0: raise ValueError('Invalid target radius')
        validate_detection(detection)


class ApiClient(QWidget):
    state = Signal(dict)
    image = Signal(bytes)
    failed = Signal(str)
    completed = Signal(str)

    def __init__(self, parent):
        super().__init__(parent)
        self.network = QNetworkAccessManager(self)
        self.url, self.token = '', ''
        self.pending = set()
        self.queued = {}
        self.generation = 0
        self.last_ok = 0.
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.poll)

    def connect_to(self, url, token):
        self.generation += 1
        self.url, self.token = url.rstrip('/'), token
        self.pending.clear()
        self.queued.clear()
        self.last_ok = 0.
        self.timer.start()
        self.poll()

    def request(self, path, payload=None, callback=None, binary=False):
        if not self.url:
            return
        if path in self.pending:
            if payload is not None:
                previous = self.queued.get(path)
                if previous and path.endswith('/assist') and previous[0].get('enabled') is False and payload.get('enabled') is True:
                    self.failed.emit('Enable cancelled: a neutral request is pending')
                    if callback: callback(None)
                else:
                    self.queued[path] = (payload, callback, binary)
            return
        generation = self.generation
        self.pending.add(path)
        request = QNetworkRequest(QUrl(self.url + path))
        request.setTransferTimeout(1800)
        # Never forward operator credentials to redirects.
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        if self.token and '/operator/' in path:
            request.setRawHeader(b'Authorization', ('Bearer ' + self.token).encode())
        if payload is None:
            reply = self.network.get(request)
        else:
            request.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, 'application/json')
            reply = self.network.post(request, json.dumps(payload).encode())

        def finished():
            if generation != self.generation:
                reply.deleteLater()
                return
            self.pending.discard(path)
            status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            body = bytes(reply.readAll())
            error = reply.error()
            if error != QNetworkReply.NetworkError.NoError or not status or not 200 <= status < 300:
                try:
                    detail = json.loads(body).get('detail', reply.errorString())
                except (ValueError, AttributeError):
                    detail = reply.errorString()
                if path != '/api/preview.jpg':
                    self.failed.emit(str(detail))
                if callback:
                    callback(None)
            else:
                try:
                    result = body if binary else (json.loads(body) if body else {})
                    if path == '/api/state':
                        validate_snapshot(result)
                        self.last_ok = time.monotonic()
                        self.state.emit(result)
                    elif path == '/api/preview.jpg' and body:
                        self.image.emit(body)
                    if payload is not None:
                        if isinstance(result, dict) and 'state' in result: validate_snapshot(result)
                        self.completed.emit(path.rsplit('/', 1)[-1])
                        if isinstance(result, dict) and 'state' in result:
                            self.state.emit(result)
                    if callback:
                        callback(result)
                except (ValueError, TypeError) as exc:
                    self.failed.emit('Invalid server response: ' + str(exc))
                    if callback:
                        callback(None)
            queued = self.queued.pop(path, None) if generation == self.generation else None
            if queued: self.request(path, queued[0], queued[1], queued[2])
            reply.deleteLater()
        reply.finished.connect(finished)

    def poll(self):
        self.request('/api/state')
        self.request('/api/preview.jpg', binary=True)

    def command(self, action, values):
        self.request('/api/operator/' + action, values)


class VideoView(QWidget):
    def __init__(self):
        super().__init__()
        self.pixmap = QPixmap()
        self.caption = 'Waiting for video'
        self.stale = False
        self.setMinimumSize(320, 240)

    def set_frame(self, data):
        pixmap = QPixmap()
        if pixmap.loadFromData(data):
            self.pixmap = pixmap
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor('#191d20'))
        if not self.pixmap.isNull():
            scaled = self.pixmap.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
            rect = QRectF((self.width() - scaled.width()) / 2, (self.height() - scaled.height()) / 2,
                          scaled.width(), scaled.height())
            painter.drawPixmap(rect, self.pixmap, QRectF(self.pixmap.rect()))
        painter.setPen(QColor('#d5dde0'))
        painter.drawText(16, self.height() - 16, self.caption)
        if self.stale:
            painter.fillRect(self.rect(), QColor(15, 18, 20, 175))
            painter.setPen(Qt.GlobalColor.white)
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, 'Connection lost · preview is stale')


class CommandPlot(QWidget):
    """Small oscilloscope-style plot of requested and accepted software yaw."""
    def __init__(self):
        super().__init__()
        self.samples = deque(maxlen=300)
        self.setMinimumHeight(115)

    def append(self, state):
        self.samples.append((state.get('yaw', 0), state.get('ack_yaw', 0)))
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor('#f4f5f6'))
        left, right, top, bottom = 44, self.width() - 16, 26, self.height() - 22
        p.setPen(QColor('#7b8389'))
        p.drawText(10, 16, 'Yaw command')
        p.drawText(max(150, self.width() - 240), 16, 'Requested     Accepted (ACK)')
        for value in (-1000, 0, 1000):
            y = top + (1000 - value) / 2000 * (bottom - top)
            p.setPen(QColor('#d8dcdf'))
            p.drawLine(QPointF(left, y), QPointF(right, y))
            p.setPen(QColor('#7b8389'))
            p.drawText(3, int(y + 4), str(value))
        for column, color in ((1, '#9ca6ae'), (0, '#24756c')):
            p.setPen(QPen(QColor(color), 1.6))
            points = [QPointF(left + i / 299 * (right - left),
                             top + (1000 - sample[column]) / 2000 * (bottom - top))
                      for i, sample in enumerate(self.samples)]
            for a, b in zip(points, points[1:]):
                p.drawLine(a, b)
        p.setPen(QColor('#7b8389'))
        p.drawText(left, self.height() - 4, '30 s history · software commands only')


class SettingsDialog(QDialog):
    def __init__(self, settings, parent):
        super().__init__(parent)
        self.setWindowTitle('Detector and controller settings')
        self.fields = {}
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('Applying settings disables assistance. Values are provisional demo settings.'))
        tabs = QTabWidget()
        layout.addWidget(tabs)
        definitions = {
            'Controller': [('gain', 'Proportional gain', 0, 2000, 1),
                           ('smoothing', 'Smoothing', .001, 1, .01),
                           ('deadband', 'Deadband', 0, .5, .01),
                           ('max_yaw', 'Maximum yaw', 0, 1000, 10),
                           ('slew_per_s', 'Slew / second', 1, 10000, 100)],
            'Detector': [('hue_low', 'Hue minimum', 0, 179, 1), ('hue_high', 'Hue maximum', 0, 179, 1),
                         ('saturation_min', 'Minimum saturation', 0, 255, 1),
                         ('value_min', 'Minimum value', 0, 255, 1),
                         ('min_area', 'Minimum blob area (px²)', 1, 50000, 10),
                         ('max_area', 'Maximum blob area (px²)', 1, 307200, 100)],
        }
        for name, entries in definitions.items():
            page, form = QWidget(), QFormLayout()
            page.setLayout(form)
            tabs.addTab(page, name)
            for key, label, low, high, step in entries:
                value = settings.get(key, low)
                field = QSpinBox() if key in ('max_yaw', 'hue_low', 'hue_high', 'saturation_min', 'value_min', 'min_area', 'max_area') else QDoubleSpinBox()
                if isinstance(field, QDoubleSpinBox):
                    field.setDecimals(3)
                field.setRange(low, high)
                field.setSingleStep(step)
                field.setValue(value)
                self.fields[key] = field
                form.addRow(label, field)
        direction = QComboBox()
        direction.addItem('Positive (+1)', 1)
        direction.addItem('Reversed (−1)', -1)
        direction.setCurrentIndex(0 if settings.get('direction', 1) == 1 else 1)
        self.fields['direction'] = direction
        tabs.widget(0).layout().addRow('Direction', direction)
        self.error = QLabel()
        layout.addWidget(self.error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Apply | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.apply)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def values(self):
        return {key: field.currentData() if isinstance(field, QComboBox) else field.value()
                for key, field in self.fields.items()}

    def apply(self):
        values = self.values()
        if values['hue_low'] > values['hue_high'] or values['min_area'] > values['max_area']:
            self.error.setText('Minimum thresholds must not exceed maximum thresholds.')
        else:
            self.accept()


class TraceWindow(QDialog):
    """Read-only replay of a fixture trace, without a live client or bridge reference."""
    def __init__(self, trace, parent):
        validate_trace(trace)
        super().__init__(parent)
        self.setWindowTitle('Isolated playback — ' + trace.get('scenario', 'trace'))
        self.resize(800, 660)
        self.samples = trace['samples']
        self.settings = trace.get('settings', {})
        self.index = 0
        layout = QVBoxLayout(self)
        label = QLabel('OFFLINE SYNTHETIC TRACE · Independent playback; no bridge commands')
        layout.addWidget(label)
        self.video = VideoView()
        layout.addWidget(self.video, 1)
        self.readout = QLabel()
        layout.addWidget(self.readout)
        row = QHBoxLayout()
        self.play = QPushButton('Play')
        self.play.clicked.connect(self.toggle)
        row.addWidget(self.play)
        reset = QPushButton('Reset')
        reset.clicked.connect(lambda: self.slider.setValue(0))
        row.addWidget(reset)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, len(self.samples) - 1)
        self.slider.valueChanged.connect(self.render)
        row.addWidget(self.slider, 1)
        layout.addLayout(row)
        self.timer = QTimer(self)
        self.timer.setInterval(round(1000 / self.settings.get('processing_hz', 20)))
        self.timer.timeout.connect(self.advance)
        self.render(0)

    def closeEvent(self, event):
        self.timer.stop()
        super().closeEvent(event)

    def reject(self):
        self.timer.stop()
        super().reject()

    def toggle(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play.setText('Play')
        else:
            if self.index == len(self.samples) - 1:
                self.slider.setValue(0)
            self.timer.start()
            self.play.setText('Pause')

    def advance(self):
        if self.index >= len(self.samples) - 1:
            self.toggle()
        else:
            self.slider.setValue(self.index + 1)

    def render(self, index):
        self.index = index
        sample = self.samples[index]
        truth = sample.get('truth', {})
        w, h = self.settings.get('width', 640), self.settings.get('height', 480)
        pixmap = QPixmap(w, h)
        pixmap.fill(QColor('#191d20'))
        p = QPainter(pixmap)
        p.setPen(QColor('#353b40'))
        for x in range(0, w, 40): p.drawLine(x, 0, x, h)
        for y in range(0, h, 40): p.drawLine(0, y, w, y)
        p.setPen(QColor('#8b9298'))
        p.drawLine(w // 2, 0, w // 2, h)
        if truth.get('visible'):
            p.setBrush(QColor('#69dc32'))
            p.setPen(Qt.PenStyle.NoPen)
            r = truth.get('radius', 25)
            p.drawEllipse(QPointF(truth['x'], truth['y']), r, r)
        detection = sample.get('detection')
        if detection and 'bbox' in detection:
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor('#b8f5cf'), 2))
            p.drawRect(QRectF(*detection['bbox']))
        p.end()
        self.video.pixmap = pixmap
        self.video.caption = 'Ground truth reconstruction · visual effects are not replayed'
        self.video.update()
        self.readout.setText(f"{sample['t']:.2f} s    {sample['state']}    Requested yaw: {sample['yaw']}    Frame {index + 1}/{len(self.samples)}")


class Workstation(QMainWindow):
    def __init__(self, backend=None, url='', token=''):
        super().__init__()
        self.backend = backend
        self.snapshot = {}
        self.authorized = False
        self.last_event = None
        self.trace_windows = []
        self.setWindowTitle('Ball Drone — Operator Workstation')
        self.resize(1220, 800)
        self.setDockOptions(QMainWindow.DockOption.AllowTabbedDocks | QMainWindow.DockOption.AllowNestedDocks)
        self.api = ApiClient(self)
        self.api.state.connect(self.update_state)
        self.api.failed.connect(self.failure)
        self.api.completed.connect(lambda action: self.statusBar().showMessage(action.capitalize() + ' accepted', 3500))
        self.build_workspace()
        self.build_menus()
        self.api.image.connect(self.video.set_frame)
        self.api.connect_to(backend.url if backend else url, backend.token if backend else token)
        self.authorized = bool(backend)
        if not backend and token:
            self.api.request('/api/operator/access', callback=self.access_checked)
        self.freshness = QTimer(self)
        self.freshness.setInterval(200)
        self.freshness.timeout.connect(self.check_freshness)
        self.freshness.start()
        self.update_access()

    def dock(self, title, widget, area):
        dock = QDockWidget(title, self)
        dock.setObjectName(title)
        dock.setWidget(widget)
        self.addDockWidget(area, dock)
        return dock

    def build_workspace(self):
        self.video = VideoView()
        self.plot = CommandPlot()
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.video)
        split.addWidget(self.plot)
        split.setSizes([510, 140])
        self.setCentralWidget(split)
        source_widget = QWidget()
        source_layout = QVBoxLayout(source_widget)
        self.source_kind = QComboBox()
        self.source_kind.addItems(['Synthetic', 'Recorded video', 'Camera'])
        source_layout.addWidget(self.source_kind)
        self.scenario = QComboBox()
        for scenario in SCENARIOS:
            self.scenario.addItem(scenario.replace('_', ' ').title(), scenario)
        self.scenario.setCurrentText('Moving')
        source_layout.addWidget(self.scenario)
        self.path = QLineEdit()
        self.path.setPlaceholderText('Video path on processing device')
        source_layout.addWidget(self.path)
        self.browse = QPushButton('Choose video…')
        self.browse.clicked.connect(self.choose_video)
        source_layout.addWidget(self.browse)
        self.camera = QSpinBox()
        self.camera.setRange(0, 10)
        self.camera.setPrefix('Camera device ')
        source_layout.addWidget(self.camera)
        self.source_apply = QPushButton('Apply source')
        self.source_apply.clicked.connect(self.apply_source)
        source_layout.addWidget(self.source_apply)
        self.source_kind.currentIndexChanged.connect(self.source_visibility)
        self.source_visibility()
        control = QGroupBox('Assistance')
        controls = QVBoxLayout(control)
        self.state_label = QLabel('MANUAL')
        font = self.state_label.font()
        font.setPointSize(19)
        font.setBold(True)
        self.state_label.setFont(font)
        controls.addWidget(self.state_label)
        self.enable = QPushButton('Enable yaw assistance')
        self.enable.clicked.connect(lambda: self.api.command('assist', {'enabled': True}))
        controls.addWidget(self.enable)
        self.disable = QPushButton('Disable · neutral')
        self.disable.clicked.connect(lambda: self.api.command('assist', {'enabled': False}))
        controls.addWidget(self.disable)
        self.settings_button = QPushButton('Detector / controller…')
        self.settings_button.clicked.connect(self.settings_dialog)
        controls.addWidget(self.settings_button)
        source_layout.addWidget(control)
        faults = QGroupBox('Mock bridge')
        fault_layout = QVBoxLayout(faults)
        self.fault_choice = QComboBox()
        for label, value in [('Normal', 'none'), ('Disconnect', 'disconnect'),
                             ('Missing ACK', 'missing_ack'), ('Delayed ACK', 'delayed_ack')]:
            self.fault_choice.addItem(label, value)
        fault_layout.addWidget(self.fault_choice)
        self.fault_apply = QPushButton('Apply bridge condition')
        self.fault_apply.clicked.connect(lambda: self.api.command('fault', {'fault': self.fault_choice.currentData()}))
        fault_layout.addWidget(self.fault_apply)
        source_layout.addWidget(faults)
        source_layout.addStretch()
        self.source_dock = self.dock('Source & control', source_widget, Qt.DockWidgetArea.LeftDockWidgetArea)
        self.source_dock.setMinimumWidth(230)
        inspect = QWidget()
        inspect_layout = QVBoxLayout(inspect)
        self.readouts = {}
        form = QFormLayout()
        mono = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        for key, label in [('yaw', 'Requested yaw'), ('ack_yaw', 'Accepted yaw'), ('error', 'Horizontal error'),
                           ('quality', 'Tracking quality¹'), ('frame_age_ms', 'Frame age'),
                           ('ack_age_ms', 'ACK age'), ('processing_ms', 'Processing'), ('bridge', 'Transport'),
                           ('bridge_fault', 'Bridge condition'), ('frames', 'Processed frames')]:
            value = QLabel('—')
            value.setFont(mono)
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.readouts[key] = value
            form.addRow(label, value)
        inspect_layout.addLayout(form)
        self.fault_label = QLabel('No active fault')
        self.fault_label.setWordWrap(True)
        inspect_layout.addWidget(self.fault_label)
        inspect_layout.addStretch()
        note = QLabel('¹ Heuristic, not a safety probability.\n\nAircraft telemetry: unavailable\nTransmitter output: not implemented')
        note.setWordWrap(True)
        inspect_layout.addWidget(note)
        self.inspect_dock = self.dock('Live measurements', inspect, Qt.DockWidgetArea.RightDockWidgetArea)
        self.inspect_dock.setMinimumWidth(245)
        self.events = QTreeWidget()
        self.events.setColumnCount(3)
        self.events.setHeaderLabels(['Time', 'Event', 'Details'])
        self.events.setRootIsDecorated(False)
        self.events.setColumnWidth(0, 85)
        self.events.setColumnWidth(1, 140)
        self.events_dock = self.dock('Session events', self.events, Qt.DockWidgetArea.BottomDockWidgetArea)
        self.events_dock.setMaximumHeight(190)
        toolbar = QToolBar('Session', self)
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.addToolBar(toolbar)
        open_action = QAction(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogOpenButton), 'Open video', self)
        open_action.triggered.connect(self.choose_video)
        toolbar.addAction(open_action)
        toolbar.addSeparator()
        self.source_label = QLabel(' SYNTHETIC ')
        toolbar.addWidget(self.source_label)
        stretch = QWidget()
        from PySide6.QtWidgets import QSizePolicy
        stretch.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        toolbar.addWidget(stretch)
        self.session_label = QLabel('Starting session…  ')
        toolbar.addWidget(self.session_label)
        self.connection_label = QLabel()
        self.statusBar().addPermanentWidget(self.connection_label)

    def build_menus(self):
        file_menu = self.menuBar().addMenu('&File')
        self.action(file_menu, 'Open recorded video…', self.choose_video, 'Ctrl+O')
        self.action(file_menu, 'Open fixture trace…', self.open_trace)
        self.action(file_menu, 'Open session folder', self.open_session_folder)
        file_menu.addSeparator()
        self.action(file_menu, 'Connect to Pi / server…', self.connect_dialog)
        self.action(file_menu, 'Open visitor page', lambda: QDesktopServices.openUrl(QUrl(self.api.url)))
        file_menu.addSeparator()
        self.action(file_menu, 'Close', self.close, 'Ctrl+W')
        view = self.menuBar().addMenu('&View')
        for dock in (self.source_dock, self.inspect_dock, self.events_dock):
            view.addAction(dock.toggleViewAction())
        tools = self.menuBar().addMenu('&Tools')
        self.action(tools, 'Detector / controller settings…', self.settings_dialog, 'Ctrl+,')
        self.action(tools, 'Reset demonstration', lambda: self.api.command('reset', {}))
        self.action(tools, 'Play isolated scenario…', self.play_scenario)
        help_menu = self.menuBar().addMenu('&Help')
        self.action(help_menu, 'About Ball Drone', lambda: QMessageBox.about(
            self, 'Ball Drone', 'Native Qt operator workstation for Mac and Raspberry Pi.\n\n'
            'Synthetic/recorded tracking and bounded yaw demonstration. '
            'ACKs describe software state. No physical transmitter output.'))

    def action(self, menu, label, callback, shortcut=None):
        action = QAction(label, self)
        if shortcut:
            action.setShortcut(shortcut)
        action.triggered.connect(callback)
        menu.addAction(action)
        return action

    def source_visibility(self):
        kind = self.source_kind.currentIndex()
        self.scenario.setVisible(kind == 0)
        self.path.setVisible(kind == 1)
        self.browse.setVisible(kind == 1)
        self.camera.setVisible(kind == 2)

    def choose_video(self):
        if not self.authorized:
            self.failure('Operator access is required to change the video source.')
            return
        if not self.backend:
            self.source_kind.setCurrentIndex(1)
            self.failure('Enter a video path that exists on the connected server, then Apply source.')
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Open recorded video', '', 'Video files (*.avi *.mp4 *.mov *.mkv);;All files (*)')
        if path:
            self.path.setText(path)
            self.source_kind.setCurrentIndex(1)
            self.apply_source()

    def apply_source(self):
        kind = ['synthetic', 'recorded', 'camera'][self.source_kind.currentIndex()]
        values = {'kind': kind}
        if kind == 'synthetic': values['scenario'] = self.scenario.currentData()
        elif kind == 'recorded': values['path'] = self.path.text()
        else: values['device'] = self.camera.value()
        self.api.command('source', values)

    def settings_dialog(self):
        if not self.authorized or not self.snapshot:
            self.failure('Connect with operator access before changing settings.')
            return
        dialog = SettingsDialog(self.snapshot['settings'], self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.api.command('settings', dialog.values())

    def access_checked(self, result):
        self.authorized = isinstance(result, dict) and result.get('authorized') is True
        self.update_access()

    def update_access(self):
        fresh = bool(self.api.last_ok and time.monotonic() - self.api.last_ok < .5)
        for control in (self.source_apply, self.settings_button, self.fault_apply):
            control.setEnabled(self.authorized and fresh)
        self.enable.setEnabled(self.authorized and fresh and not self.snapshot.get('enabled', False))
        self.disable.setEnabled(self.authorized)
        self.browse.setEnabled(self.authorized)

    def update_state(self, state):
        self.snapshot = state
        self.state_label.setText(state['state'])
        self.source_label.setText(' ' + state['source_label'] + ' ')
        self.video.caption = f"{state['source_label']} · {state['source'].get('scenario', state['source']['kind'])}"
        self.video.stale = False
        self.video.update()
        self.session_label.setText(state['session'] + '  ')
        detection = state.get('detection') or {}
        for key, label in self.readouts.items():
            value = detection.get(key) if key in ('error', 'quality') else state.get(key)
            text = '—' if value is None else f'{value:.3f}' if key in ('error', 'quality') else str(value)
            if value is not None and key.endswith('_ms'): text += ' ms'
            label.setText(text)
        self.fault_label.setText('Fault: ' + state['fault'] if state.get('fault') else 'No active fault')
        self.plot.append(state)
        event = (state['state'], state.get('fault'), state['source_label'], json.dumps(state['source']), state['enabled'])
        if event != self.last_event:
            self.add_event(state['state'], state.get('fault') or (state['source_label'] + ' · assistance ' + ('enabled' if state['enabled'] else 'disabled')))
            self.last_event = event
        mode = 'Local session' if self.backend else ('Remote operator' if self.authorized else 'Remote viewer')
        self.connection_label.setText(f'{mode}  ·  {self.api.url}')
        self.update_access()

    def check_freshness(self):
        stale = not self.api.last_ok or time.monotonic() - self.api.last_ok > .5
        self.video.stale = stale
        self.video.update()
        if stale:
            self.connection_label.setText('Disconnected / waiting  ·  ' + self.api.url)
            self.state_label.setText('OFFLINE')
            for label in self.readouts.values(): label.setText('—')
        self.update_access()

    def failure(self, message):
        self.statusBar().showMessage(message, 8000)
        # Avoid filling the event list with every reconnect attempt.
        if not getattr(self, '_last_error', None) == message:
            self.add_event('Client', message)
            self._last_error = message

    def add_event(self, kind, detail):
        self.events.addTopLevelItem(QTreeWidgetItem([time.strftime('%H:%M:%S'), kind, detail]))
        if self.events.topLevelItemCount() > 300:
            self.events.takeTopLevelItem(0)
        self.events.scrollToBottom()

    def neutral_remote(self):
        if not self.authorized:
            return True
        loop = QEventLoop()
        result = []
        self.api.request('/api/operator/assist', {'enabled': False},
                         callback=lambda reply: (result.append(reply), loop.quit()))
        QTimer.singleShot(2000, loop.quit)
        loop.exec()
        if not result: return False
        try: validate_snapshot(result[0])
        except ValueError: return False
        return result[0]['enabled'] is False and result[0]['yaw'] == 0

    def connect_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle('Connect to Pi / demo server')
        form = QFormLayout(dialog)
        url = QLineEdit('http://ball-drone.local:8080')
        token = QLineEdit()
        token.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow('Server URL', url)
        form.addRow('Operator token (optional)', token)
        form.addRow(QLabel('Leave the token empty for read-only viewing.\nTokens are kept in memory only; use a trusted demo network.'))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        address = url.text().strip().rstrip('/')
        parsed = urlparse(address)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
            QMessageBox.warning(self, 'Invalid server', 'Use an HTTP(S) origin such as http://ball-drone.local:8080.')
            return
        if self.backend:
            self.backend.stop()
            self.backend = None
        elif not self.neutral_remote():
            QMessageBox.warning(self, 'Could not confirm neutral', 'The previous server did not confirm disabled assistance. Reconnect and disable it before switching servers.')
            return
        self.authorized = False
        self.snapshot = {}
        self.video.pixmap = QPixmap()
        self.plot.samples.clear()
        self.api.connect_to(address, token.text())
        if token.text(): self.api.request('/api/operator/access', callback=self.access_checked)
        self.update_access()

    def open_session_folder(self):
        if self.backend:
            folder = self.backend.data / 'sessions' / self.snapshot.get('session', '')
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        else:
            self.failure('Session files are stored on the connected server, not on this device.')

    def show_trace(self, trace):
        try:
            if not isinstance(trace, dict) or not trace.get('samples'):
                raise ValueError('No fixture samples found')
            dialog = TraceWindow(trace, self)
        except (KeyError, TypeError, ValueError) as error:
            self.failure('Not a compatible synthetic fixture trace: ' + str(error))
            return
        self.trace_windows.append(dialog)
        dialog.show()

    def open_trace(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Open synthetic fixture trace', '', 'JSON trace (*.json)')
        if path:
            try: self.show_trace(json.loads(Path(path).read_text()))
            except (ValueError, OSError) as error: self.failure(str(error))

    def play_scenario(self):
        self.api.request('/api/sandbox/' + self.scenario.currentData(), callback=self.show_trace)
        self.statusBar().showMessage('Loading isolated fixture trace…', 3000)

    def closeEvent(self, event):
        if self.backend:
            self.backend.stop()
            self.backend = None
        elif not self.neutral_remote():
            QMessageBox.warning(self, 'Could not confirm neutral', 'The server did not acknowledge disable. This window will stay open so you can reconnect. A client disconnect does not itself stop a remote server.')
            event.ignore()
            return
        self.api.timer.stop()
        self.freshness.stop()
        self.authorized = False
        event.accept()


def main():
    multiprocessing.freeze_support()
    parser = argparse.ArgumentParser(description='Native Ball Drone workstation for Mac and Pi')
    parser.add_argument('--connect', help='Connect to a running Pi/server instead of starting a local mock session')
    parser.add_argument('--token-file', type=Path, help='Operator token file for a connected server; omitted means viewer')
    parser.add_argument('--data', type=Path, help='Local sessions/private token directory')
    parser.add_argument('--listen', default='0.0.0.0', help='Local visitor server bind address')
    parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--snapshot', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--quit-after', type=float, help=argparse.SUPPRESS)
    args = parser.parse_args()
    # This Mac's .venv plugin files carry UF_HIDDEN flags; Qt skips them.
    # Copy without file metadata for source launches rather than changing the venv.
    # The standalone .app has visible bundled plugins and needs no workaround.
    plugins = Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath))
    plugin_cache = None
    if sys.platform == 'darwin' and QFileInfo(str(plugins / 'platforms/libqcocoa.dylib')).isHidden():
        plugin_cache = tempfile.TemporaryDirectory(prefix='ball-drone-qt-', dir='/tmp')
        cache = Path(plugin_cache.name)
        shutil.copytree(plugins, cache, dirs_exist_ok=True, copy_function=shutil.copy)
        os.environ['QT_PLUGIN_PATH'] = str(cache)
        os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = str(cache / 'platforms')
        QCoreApplication.setLibraryPaths([str(cache)])
    app = QApplication([sys.argv[0]])
    app.setApplicationName('Ball Drone')
    app.setOrganizationName('BallDrone')
    app.setApplicationDisplayName('Ball Drone')
    icon = Path(__file__).parent / 'static' / 'desktop-icon.png'
    if icon.exists(): app.setWindowIcon(QIcon(str(icon)))
    data = args.data or Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation))
    backend = None
    try:
        if not args.connect:
            from .desktop_backend import DesktopBackend
            backend = DesktopBackend(data, args.listen, args.port)
        token = args.token_file.read_text().strip() if args.token_file else ''
        window = Workstation(backend, args.connect or '', token)
    except Exception as error:
        if backend: backend.stop()
        QMessageBox.critical(None, 'Cannot start Ball Drone', str(error))
        return 1
    window.show()
    if backend: QTimer.singleShot(0, backend.start)
    def shutdown():
        if window.backend:
            window.backend.stop()
            window.backend = None
    app.aboutToQuit.connect(shutdown)
    if args.snapshot:
        def capture():
            args.snapshot.parent.mkdir(parents=True, exist_ok=True)
            window.grab().save(str(args.snapshot))
        QTimer.singleShot(2500, capture)
    if args.quit_after:
        QTimer.singleShot(int(args.quit_after * 1000), window.close)
    result = app.exec()
    if plugin_cache: plugin_cache.cleanup()
    return result


if __name__ == '__main__':
    sys.exit(main())
