import asyncio
import hmac
import json
import os
import secrets
import math
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, StreamingResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .engine import Engine
from .fixtures import trace
from .sources import SCENARIOS


class OperatorRequest(BaseModel):
    # Operator intent must be explicit: do not coerce strings/bools into
    # commands or silently discard misspelled control fields.
    model_config = ConfigDict(strict=True, extra='forbid')


class SourceRequest(OperatorRequest):
    kind: str = 'synthetic'
    scenario: str = 'moving'
    path: str | None = None
    device: int = Field(default=0, ge=0, le=10)
    @model_validator(mode='after')
    def valid(self):
        if self.kind not in ['synthetic', 'recorded', 'camera']: raise ValueError('Invalid source kind')
        if self.scenario not in SCENARIOS: raise ValueError('Unknown scenario')
        if self.kind == 'recorded' and (not self.path or not Path(self.path).is_file()): raise ValueError('Recorded file must exist on the server')
        return self


class SettingsRequest(OperatorRequest):
    gain: float | None = Field(None, ge=0, le=2000)
    smoothing: float | None = Field(None, gt=0, le=1)
    deadband: float | None = Field(None, ge=0, le=.5)
    max_yaw: int | None = Field(None, ge=0, le=1000)
    slew_per_s: float | None = Field(None, gt=0, le=10000)
    direction: int | None = None
    hue_low: int | None = Field(None, ge=0, le=179)
    hue_high: int | None = Field(None, ge=0, le=179)
    saturation_min: int | None = Field(None, ge=0, le=255)
    value_min: int | None = Field(None, ge=0, le=255)
    min_area: int | None = Field(None, ge=1, le=50000)
    max_area: int | None = Field(None, ge=1, le=307200)
    @model_validator(mode='after')
    def valid(self):
        if self.direction not in [None, -1, 1]: raise ValueError('Direction must be -1 or 1')
        return self


class AssistRequest(OperatorRequest):
    enabled: bool


class FaultRequest(OperatorRequest):
    fault: str


def create_app(engine=None, token=None):
    engine = engine or Engine(os.environ.get('BALL_DATA_DIR', 'runs'))
    token = token or os.environ.get('BALL_OPERATOR_TOKEN') or secrets.token_urlsafe(24)
    @asynccontextmanager
    async def lifespan(app):
        engine.start()
        yield
        engine.stop()
    app = FastAPI(title='Ball Drone software demonstration', lifespan=lifespan)
    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, error):
        # Keep invalid NaN/Infinity input out of JSON error responses, too.
        def safe(value):
            if isinstance(value, float) and not math.isfinite(value): return str(value)
            if isinstance(value, dict): return {key: safe(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)): return [safe(item) for item in value]
            if isinstance(value, Exception): return str(value)
            return value
        return JSONResponse(status_code=422, content={'detail': safe(error.errors())})
    app.state.engine, app.state.operator_token = engine, token
    static = Path(__file__).parent / 'static'
    app.mount('/assets', StaticFiles(directory=static), name='assets')
    async def operator(authorization: str = Header(default='')):
        if not hmac.compare_digest(authorization, 'Bearer ' + token):
            raise HTTPException(401, 'Operator token required')
    @app.get('/')
    async def index(): return FileResponse(static / 'index.html')
    @app.get('/api/health')
    async def health():
        s = engine.snapshot()
        return {'ok': engine.running, 'service': 'ball-demo', 'version': '0.1.0', 'state': s['state'], 'physical_output': False}
    @app.get('/api/state')
    async def state(): return engine.snapshot()
    @app.get('/api/preview.jpg')
    async def preview_frame():
        # Reuse the shared encoded frame for native clients; never re-encode per viewer.
        with engine.lock: frame = engine.preview
        if frame is None: return Response(status_code=204)
        return Response(frame, media_type='image/jpeg', headers={'Cache-Control': 'no-store'})
    @app.get('/api/operator/access', dependencies=[Depends(operator)])
    async def access(): return {'authorized': True}
    @app.get('/api/events')
    async def events():
        async def stream():
            while engine.running:
                yield 'data: ' + json.dumps(engine.snapshot()) + '\n\n'
                await asyncio.sleep(.1)
        return StreamingResponse(stream(), media_type='text/event-stream', headers={'Cache-Control': 'no-store'})
    @app.get('/api/preview')
    async def preview():
        async def stream():
            previous = -1
            while engine.running:
                with engine.lock: frame, index = engine.preview, engine.preview_index
                if frame is not None and index != previous:
                    previous = index
                    yield b'--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ' + str(len(frame)).encode() + b'\r\n\r\n' + frame + b'\r\n'
                await asyncio.sleep(.1)
        return StreamingResponse(stream(), media_type='multipart/x-mixed-replace; boundary=frame', headers={'Cache-Control': 'no-store'})
    @app.get('/api/scenarios')
    async def scenarios(): return SCENARIOS
    # Precompute once per scenario; no live bridge is reachable from trace generation.
    cache = {}
    cache_locks = {name: asyncio.Lock() for name in SCENARIOS}
    @app.get('/api/sandbox/{scenario}')
    async def sandbox(scenario: str):
        if scenario not in SCENARIOS: raise HTTPException(404, 'Unknown scenario')
        async with cache_locks[scenario]:
            if scenario not in cache: cache[scenario] = await asyncio.to_thread(trace, scenario)
        return cache[scenario]
    @app.post('/api/operator/assist', dependencies=[Depends(operator)])
    async def assist(request: AssistRequest):
        try: engine.assist(request.enabled)
        except ValueError as error: raise HTTPException(409, str(error))
        return engine.snapshot()
    @app.post('/api/operator/source', dependencies=[Depends(operator)])
    async def source(request: SourceRequest):
        engine.set_source(request.model_dump(exclude_none=True))
        return engine.snapshot()
    @app.post('/api/operator/settings', dependencies=[Depends(operator)])
    async def settings(request: SettingsRequest):
        values = request.model_dump(exclude_none=True)
        candidate = {**engine.settings.dict(), **values}
        if candidate['hue_low'] > candidate['hue_high'] or candidate['min_area'] > candidate['max_area']:
            raise HTTPException(422, 'Lower threshold must not exceed upper threshold')
        engine.configure(values)
        return engine.snapshot()
    @app.post('/api/operator/fault', dependencies=[Depends(operator)])
    async def fault(request: FaultRequest):
        if request.fault not in ['none', 'disconnect', 'missing_ack', 'delayed_ack']: raise HTTPException(422, 'Unknown fault')
        try: engine.inject(request.fault)
        except ValueError as error: raise HTTPException(409, str(error))
        return engine.snapshot()
    @app.post('/api/operator/reset', dependencies=[Depends(operator)])
    async def reset():
        from .bridge import MockBridge
        if isinstance(engine.bridge, MockBridge): engine.inject('none')
        engine.set_source({'kind': 'synthetic', 'scenario': 'moving'})
        return engine.snapshot()
    return app
