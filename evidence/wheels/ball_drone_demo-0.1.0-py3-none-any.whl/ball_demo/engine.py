import threading
import time
from pathlib import Path

import cv2

from .bridge import MockBridge
from .config import Settings
from .control import Controller
from .session import Session
from .sources import OpenCVSource, SyntheticSource
from .vision import Detector


class Engine:
    """Capture may block; control and neutralization have their own clock/thread."""
    def __init__(self, root, settings=None, bridge=None, source=None):
        self.settings = settings or Settings()
        self.bridge = bridge or MockBridge(self.settings.watchdog_ms)
        self.controller = Controller()
        self.lock = threading.RLock()
        self.source_spec = source or {'kind': 'synthetic', 'scenario': 'moving'}
        self.generation = 0
        self.frame = None
        self.detection = None
        self.processing_ms = None
        self.preview = None
        self.preview_index = 0
        self.processed = 0
        self.source_error = None
        self.eof = False
        self.running = False
        self.started = time.monotonic()
        self.session = Session(root, self.settings, self.source_spec)
        self.current_source = None
        self.threads = []
    def start(self):
        self.running = True
        for target in (self.capture_loop, self.control_loop):
            thread = threading.Thread(target=target, daemon=True)
            thread.start()
            self.threads.append(thread)
        self.session.event('startup', {'state': 'MANUAL', 'bridge': self.bridge.transport})
    def stop(self):
        with self.lock:
            self.controller.enable(False)
            try: self.bridge.send(False, 0, time.monotonic())
            except Exception as error: self.session.event('neutral_send_failed', {'reason': str(error)})
            self.running = False
        for thread in self.threads: thread.join(timeout=1)
        with self.lock:
            try: self.bridge.close()
            except Exception as error: self.session.event('bridge_close_failed', {'reason': str(error)})
            self.session.event('shutdown', {'yaw': 0})
            self.session.close(self.processed)
    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            return {'state': self.controller.state, 'enabled': self.controller.enabled,
                    'yaw': self.controller.yaw, 'ack_yaw': self.bridge.accepted_yaw,
                    'bridge': self.bridge.transport, 'bridge_fault': self.bridge.fault,
                    'source': dict(self.source_spec),
                    'source_label': {'synthetic': 'SYNTHETIC', 'recorded': 'RECORDED', 'camera': 'CAMERA'}[self.source_spec['kind']],
                    'frame_age_ms': round((now - self.frame.captured) * 1000, 1) if self.frame else None,
                    'ack_age_ms': round((now - self.bridge.last_ack) * 1000, 1),
                    'fault': self.controller.fault, 'detection': self.detection,
                    'processing_ms': self.processing_ms, 'frames': self.processed,
                    'preview_index': self.preview_index, 'settings': self.settings.dict(),
                    'session': self.session.id, 'physical_telemetry': None,
                    'physical_output': False, 'quality_label': 'heuristic, not a safety probability'}
    def assist(self, enabled):
        with self.lock:
            now = time.monotonic()
            if enabled and (self.frame is None or self.eof or self.source_error or
                            now - self.frame.captured >= self.settings.stale_ms / 1000 or
                            now - self.bridge.last_ack >= self.settings.ack_ms / 1000 or
                            self.bridge.fault != 'none'):
                raise ValueError('Resolve the source or bridge fault before enabling assistance')
            self.controller.enable(enabled)
            if not enabled:
                try: self.bridge.send(False, 0, now)
                except Exception as error:
                    self.controller.fail('bridge: ' + str(error))
                    self.session.event('neutral_send_failed', {'reason': str(error)})
            self.session.event('operator_assistance', {'enabled': enabled})
    def set_source(self, spec):
        with self.lock:
            self.assist(False)
            self.source_spec = spec
            self.generation += 1
            self.frame, self.detection, self.preview = None, None, None
            self.source_error, self.eof = None, False
            self.started = time.monotonic()
            self.session.event('source', spec)
    def configure(self, values):
        with self.lock:
            self.assist(False)
            for key, value in values.items(): setattr(self.settings, key, value)
            self.session.event('settings', values)
    def inject(self, fault):
        if not isinstance(self.bridge, MockBridge): raise ValueError('Fault injection is for the mock bridge only')
        with self.lock:
            self.bridge.fault = fault
            if fault == 'none':
                self.bridge.pending.clear()
                now = time.monotonic()
                self.bridge.send(False, 0, now)
                self.bridge.poll(now)
                # A recovered transport never restores operator assistance.
                self.controller.enable(False)
            self.session.event('bridge_injection', {'fault': fault})
    def capture_loop(self):
        source, generation, detector = None, -1, Detector()
        last_preview = 0.
        try:
            while self.running:
                tick = time.monotonic()
                with self.lock:
                    spec, requested = dict(self.source_spec), self.generation
                    settings = Settings(**self.settings.dict())
                if requested != generation:
                    if source: source.close()
                    generation, detector = requested, Detector()
                    try:
                        source = SyntheticSource(settings, spec.get('scenario', 'moving')) if spec['kind'] == 'synthetic' else OpenCVSource(spec['path'] if spec['kind'] == 'recorded' else spec.get('device', 0), settings, spec['kind'] == 'recorded')
                        self.current_source = source
                    except Exception as error:
                        with self.lock:
                            if generation == self.generation: self.source_error = str(error)
                        source = None
                if source is None:
                    time.sleep(.05)
                    continue
                if isinstance(source, SyntheticSource): source.yaw = self.controller.yaw
                try: frame = source.read()
                except Exception as error:
                    if not self.running: break
                    with self.lock:
                        # A replaced source may finish its blocked read after the
                        # operator has selected another input. Its failure belongs
                        # to the old generation, not the new source's fault state.
                        if generation == self.generation: self.source_error = str(error)
                    time.sleep(.05)
                    continue
                if not self.running: break
                if frame is None:
                    if getattr(source, 'eof', False):
                        with self.lock:
                            if generation == self.generation and not self.eof:
                                self.eof = True
                                self.controller.enable(False)
                                self.session.event('eof', {'action': 'MANUAL'})
                    time.sleep(.01)
                    continue
                if self.frame is not None and generation == self.generation and frame.index == self.frame.index:
                    time.sleep(1 / settings.processing_hz)
                    continue
                began = time.monotonic()
                detection = detector.detect(frame.image, settings)
                processing_ms = round((time.monotonic() - began) * 1000, 3)
                jpeg = None
                if began - last_preview >= 1 / settings.preview_hz:
                    image = frame.image.copy()
                    cv2.line(image, (settings.width // 2, 0), (settings.width // 2, settings.height), (160, 164, 168), 1)
                    if detection:
                        x, y, w, h = detection['bbox']
                        cv2.rectangle(image, (x - 4, y - 4), (x + w + 4, y + h + 4), (90, 240, 160), 2)
                    cv2.putText(image, source.label, (18, 28), cv2.FONT_HERSHEY_SIMPLEX, .65, (210, 224, 233), 1)
                    ok, encoded = cv2.imencode('.jpg', image, [cv2.IMWRITE_JPEG_QUALITY, 75])
                    if ok: jpeg = encoded.tobytes()
                    last_preview = began
                with self.lock:
                    if generation == self.generation:
                        self.frame, self.detection, self.processing_ms = frame, detection, processing_ms
                        # Retain every loss even if the latest-frame mailbox is overwritten
                        # before a control tick; neutral bypasses filtering/slew immediately.
                        if detection is None and self.controller.enabled:
                            self.controller.neutral()
                            self.controller.transition('SEARCHING', 'target lost')
                        self.processed += 1
                        if jpeg is not None:
                            self.preview, self.preview_index = jpeg, self.preview_index + 1
                time.sleep(max(0, 1 / settings.processing_hz - (time.monotonic() - tick)))
        finally:
            if source: source.close()
    def control_loop(self):
        previous_key = None
        last = time.monotonic()
        while self.running:
            tick = time.monotonic()
            with self.lock:
                try:
                    acks = self.bridge.poll(tick)
                    for ack in acks: self.session.event('ack', ack)
                    reason = None
                    if self.source_error: reason = 'source: ' + self.source_error
                    elif not self.eof and tick - (self.frame.captured if self.frame else self.started) >= self.settings.stale_ms / 1000: reason = 'stale frame'
                    elif tick - self.bridge.last_ack >= self.settings.ack_ms / 1000: reason = 'missing acknowledgement'
                    if reason and self.controller.state != 'FAULT':
                        self.controller.fail(reason)
                        self.session.event('fault', {'reason': reason, 'yaw': 0})
                    key = (self.generation, self.frame.index) if self.frame else None
                    if key is not None and key != previous_key and not reason and not self.eof:
                        self.controller.frame(self.detection, self.settings, tick - last)
                        previous_key = key
                    self.bridge.send(self.controller.enabled and self.controller.state == 'LOCKED', self.controller.yaw, tick)
                    state = self.snapshot()
                    self.session.sample(state)
                    self.session.event('command', {'seq': self.bridge.seq, 'enabled': self.controller.enabled and self.controller.state == 'LOCKED', 'yaw': self.controller.yaw})
                    for event in self.controller.events: self.session.event('state', event)
                    self.controller.events.clear()
                except Exception as error:
                    self.controller.fail('bridge: ' + str(error))
                    self.session.event('fault', {'reason': str(error), 'yaw': 0})
            last = tick
            time.sleep(max(0, 1 / self.settings.control_hz - (time.monotonic() - tick)))
