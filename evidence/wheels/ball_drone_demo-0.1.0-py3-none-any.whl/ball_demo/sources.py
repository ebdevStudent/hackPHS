import math
import time
from dataclasses import dataclass

import cv2
import numpy as np

SCENARIOS = ['centered', 'moving', 'approach', 'edges', 'brightness', 'distractions', 'small',
             'occlusion', 'blur', 'noise', 'loss', 'absent', 'reappear', 'freeze', 'delay', 'stop', 'response']


@dataclass
class Frame:
    image: np.ndarray
    captured: float
    index: int
    truth: dict


def synthetic(index, settings, scenario='moving', yaw=0, plant_x=None):
    w, h = settings.width, settings.height
    t = index / settings.processing_hz
    x = w / 2 if scenario == 'centered' else w / 2 + w * .30 * math.sin(t * .8)
    y, radius, visible = h / 2, 25, True
    if scenario == 'approach': radius = int(10 + 45 * (1 + math.sin(t)) / 2)
    if scenario == 'edges': x = 28 + (w - 56) * (1 + math.sin(t)) / 2
    if scenario == 'small': radius = 4
    if scenario == 'loss': visible = not (2 <= t % 8 < 4)
    if scenario == 'absent': visible = False
    if scenario == 'reappear':
        visible = not (2 <= t % 8 < 5)
        x = w * (.25 if t % 8 < 2 else .75)
    if scenario == 'response': x = float(plant_x if plant_x is not None else w * .8)
    image = np.full((h, w, 3), (24, 30, 33), np.uint8)
    for gx in range(0, w, 40): cv2.line(image, (gx, 0), (gx, h), (32, 39, 42), 1)
    for gy in range(0, h, 40): cv2.line(image, (0, gy), (w, gy), (32, 39, 42), 1)
    color = (50, 220, 105)
    if scenario == 'brightness': color = tuple(int(c * (.4 + .6 * (1 + math.sin(t)) / 2)) for c in color)
    if visible:
        cv2.circle(image, (round(x), round(y)), radius, color, -1)
    if scenario == 'distractions' and index > 10:
        cv2.circle(image, (int(w * .12), int(h * .22)), 32, color, -1)
    if scenario == 'occlusion':
        cv2.rectangle(image, (round(x), round(y - radius)), (round(x + radius), round(y + radius)), (24, 30, 33), -1)
    if scenario == 'blur': image = cv2.GaussianBlur(image, (17, 17), 4)
    if scenario == 'noise':
        noise = np.random.default_rng(index).normal(0, 16, image.shape)
        image = np.clip(image.astype(float) + noise, 0, 255).astype(np.uint8)
    return image, {'x': round(x), 'y': round(y), 'radius': radius, 'visible': visible,
                   'clear': scenario in ['centered', 'moving', 'approach', 'edges', 'loss', 'reappear', 'response']}


class SyntheticSource:
    label = 'SYNTHETIC'
    def __init__(self, settings, scenario='moving'):
        self.settings, self.scenario, self.index = settings, scenario, 0
        self.last = None
        self.yaw = 0
        self.plant_x = settings.width * .8
    def read(self):
        t = self.index / self.settings.processing_hz
        if self.scenario in ['stop', 'freeze', 'delay'] and t >= 2:
            if self.scenario == 'stop':
                time.sleep(.05)
                return None
            if self.scenario == 'freeze':
                return self.last
            time.sleep(.40)
        self.plant_x = max(30, min(self.settings.width - 30, self.plant_x - self.yaw / 1000 * 9))
        image, truth = synthetic(self.index, self.settings, self.scenario, self.yaw, self.plant_x)
        self.last = Frame(image, time.monotonic(), self.index, truth)
        self.index += 1
        return self.last
    def close(self): pass


class OpenCVSource:
    def __init__(self, identifier, settings, recorded=False):
        self.label = 'RECORDED' if recorded else 'CAMERA'
        self.recorded, self.settings, self.index, self.eof = recorded, settings, 0, False
        self.capture = cv2.VideoCapture(identifier)
        if not self.capture.isOpened():
            self.capture.release()
            raise ValueError('Cannot open video source')
        if not recorded:
            self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, settings.width)
            self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, settings.height)
            self.capture.set(cv2.CAP_PROP_FPS, settings.processing_hz)
    def read(self):
        ok, image = self.capture.read()
        if not ok:
            self.eof = self.recorded
            return None
        image = cv2.resize(image, (self.settings.width, self.settings.height))
        frame = Frame(image, time.monotonic(), self.index, {})
        self.index += 1
        return frame
    def close(self): self.capture.release()

