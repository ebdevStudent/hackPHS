const element = (id) => document.getElementById(id);
const displayName = (value) => value.replaceAll('_', ' ').replace(/^./, (letter) => letter.toUpperCase());

let operatorToken = '';
let lastUpdate = 0;
let currentState = null;
let playback = null;
let playbackIndex = 0;
let playing = false;
let playbackClock = 0;

const settingFields = {
  gain: 'gain', max_yaw: 'max-yaw', deadband: 'deadband', smoothing: 'smoothing',
  slew_per_s: 'slew', direction: 'direction', hue_low: 'hue-low', hue_high: 'hue-high',
  saturation_min: 'saturation-min', value_min: 'value-min', min_area: 'min-area', max_area: 'max-area',
};

function renderState(state) {
  currentState = state;
  lastUpdate = Date.now();
  element('connection').textContent = 'Connected';
  element('connection').classList.remove('stale');
  element('source-label').textContent = state.source_label;
  element('scenario-label').textContent = displayName(state.source.scenario || state.source.kind);
  element('preview').alt = `${state.source_label.toLowerCase()} video with target detection outline`;
  element('session-id').textContent = `Session ${state.session}`;
  element('state').textContent = state.state;
  element('state').dataset.state = state.state;
  const yawUnit = document.createElement('em');
  yawUnit.textContent = ' / 1000';
  element('yaw').replaceChildren(String(state.yaw), yawUnit);
  element('error').textContent = state.detection ? state.detection.error.toFixed(3) : '—';
  element('assistance').textContent = state.enabled ? 'Enabled' : 'Disabled';
  element('frame-age').textContent = state.frame_age_ms === null ? '—' : `${Math.round(state.frame_age_ms)} ms`;
  element('ack-age').textContent = `${Math.round(state.ack_age_ms)} ms`;
  element('ack-yaw').textContent = state.ack_yaw;
  element('quality').textContent = state.detection ? `${Math.round(state.detection.quality * 100)} / 100` : '—';
  element('bridge').textContent = state.bridge;
  element('yaw-marker').style.left = `${50 + state.yaw / 20}%`;
  element('fault-box').classList.toggle('hidden', !state.fault);
  element('fault-box').textContent = state.fault ? `${state.fault}. Assistance disabled; requested yaw is zero.` : '';
  element('limits-note').textContent = `Acquire: ${state.settings.acquire_frames} frames. Frame limit: ${state.settings.stale_ms} ms. ACK limit: ${state.settings.ack_ms} ms.`;
}

function markDisconnected(message) {
  element('connection').textContent = message;
  element('connection').classList.add('stale');
}

const stateStream = new EventSource('/api/events');
stateStream.onmessage = (event) => renderState(JSON.parse(event.data));
stateStream.onerror = () => markDisconnected('Disconnected');
stateStream.onopen = async () => {
  try {
    const response = await fetch('/api/state');
    if (!response.ok) throw new Error('State unavailable');
    renderState(await response.json());
    element('preview').src = '/api/preview';
  } catch {
    markDisconnected('Reconnecting');
  }
};
setInterval(() => {
  if (Date.now() - lastUpdate > 1500) markDisconnected('Stale / reconnecting');
}, 500);

function selectView(view) {
  for (const name of ['monitor', 'sandbox']) {
    const selected = name === view;
    element(`${name}-view`).classList.toggle('hidden', !selected);
    element(`${name}-tab`).classList.toggle('selected', selected);
    element(`${name}-tab`).setAttribute('aria-selected', String(selected));
  }
  if (view === 'monitor') {
    playing = false;
    element('sandbox-play').textContent = 'Play';
  } else {
    drawPlayback();
  }
  document.title = `Ball Drone — ${displayName(view)}`;
}
element('monitor-tab').onclick = () => selectView('monitor');
element('sandbox-tab').onclick = () => selectView('sandbox');

async function operatorAction(path, data) {
  const response = await fetch(`/api/operator/${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${operatorToken}` },
    body: JSON.stringify(data),
  });
  const state = await response.json();
  if (!response.ok) throw new Error(typeof state.detail === 'string' ? state.detail : JSON.stringify(state.detail));
  renderState(state);
  return state;
}

function bindAction(id, path, data, message) {
  element(id).onclick = async () => {
    try {
      await operatorAction(path, data());
      element('operator-message').textContent = message;
    } catch (error) {
      element('operator-message').textContent = error.message;
    }
  };
}

function renderSourceFields() {
  const synthetic = element('source-kind').value === 'synthetic';
  element('scenario-field').classList.toggle('hidden', !synthetic);
  element('source-path-field').classList.toggle('hidden', synthetic);
}
element('source-kind').onchange = renderSourceFields;

function populateOperatorFields() {
  if (!currentState) return;
  for (const [setting, id] of Object.entries(settingFields)) element(id).value = currentState.settings[setting];
  element('source-kind').value = currentState.source.kind;
  element('operator-scenario').value = currentState.source.scenario || 'moving';
  element('source-path').value = currentState.source.path ?? currentState.source.device ?? '';
  renderSourceFields();
}

element('operator-open').onclick = () => element('login').showModal();
element('login-cancel').onclick = () => element('login').close();
element('operator-lock').onclick = () => {
  operatorToken = '';
  element('operator-panel').classList.add('hidden');
};
element('login-form').onsubmit = async (event) => {
  event.preventDefault();
  operatorToken = element('token').value;
  try {
    const response = await fetch('/api/operator/access', { headers: { Authorization: `Bearer ${operatorToken}` } });
    if (!response.ok) throw new Error('Operator token required');
    populateOperatorFields();
    selectView('monitor');
    element('operator-panel').classList.remove('hidden');
    element('login').close();
    element('token').value = '';
    element('login-error').textContent = '';
  } catch (error) {
    operatorToken = '';
    element('login-error').textContent = error.message;
  }
};

bindAction('enable', 'assist', () => ({ enabled: true }), 'Assistance enabled. Waiting for stable acquisition.');
bindAction('disable', 'assist', () => ({ enabled: false }), 'Assistance disabled. Requested yaw: 0.');
bindAction('reset', 'reset', () => ({}), 'Reset to synthetic input; assistance disabled.');
bindAction('fault-apply', 'fault', () => ({ fault: element('bridge-fault').value }), 'Bridge setting applied.');
bindAction('source-apply', 'source', () => {
  const kind = element('source-kind').value;
  const source = { kind };
  if (kind === 'synthetic') source.scenario = element('operator-scenario').value;
  if (kind === 'recorded') source.path = element('source-path').value;
  if (kind === 'camera') source.device = Number(element('source-path').value || 0);
  return source;
}, 'Source changed. Assistance disabled.');
bindAction('settings-apply', 'settings', () => Object.fromEntries(
  Object.entries(settingFields).map(([setting, id]) => [setting, Number(element(id).value)]),
), 'Settings applied. Assistance disabled.');

async function loadPlayback() {
  playing = false;
  playbackIndex = 0;
  element('sandbox-play').textContent = 'Play';
  try {
    const response = await fetch(`/api/sandbox/${element('sandbox-scenario').value}`);
    if (!response.ok) throw new Error('Scene unavailable');
    playback = await response.json();
    drawPlayback();
  } catch (error) {
    element('sandbox-state').textContent = error.message;
  }
}

function drawPlayback() {
  if (!playback?.samples?.length) return;
  const sample = playback.samples[Math.min(playbackIndex, playback.samples.length - 1)];
  const canvas = element('sandbox-canvas');
  const context = canvas.getContext('2d');
  context.fillStyle = '#11171a';
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = '#2b343b';
  context.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 80) {
    context.beginPath(); context.moveTo(x, 0); context.lineTo(x, canvas.height); context.stroke();
  }
  for (let y = 0; y < canvas.height; y += 80) {
    context.beginPath(); context.moveTo(0, y); context.lineTo(canvas.width, y); context.stroke();
  }
  context.strokeStyle = '#8d969d';
  context.beginPath(); context.moveTo(320, 0); context.lineTo(320, 480); context.stroke();
  if (sample.truth?.visible) {
    context.fillStyle = '#69dc32';
    context.beginPath(); context.arc(sample.truth.x, sample.truth.y, sample.truth.radius || 25, 0, 2 * Math.PI); context.fill();
  }
  if (sample.detection?.bbox) {
    context.strokeStyle = '#9ee07a'; context.lineWidth = 2; context.strokeRect(...sample.detection.bbox);
  }
  context.fillStyle = '#bac3ca'; context.font = '12px monospace';
  context.fillText(playback.label || 'REPLAY / NO BRIDGE OUTPUT', 14, 22);
  element('sandbox-time').textContent = `${sample.t.toFixed(2)} s`;
  element('sandbox-state').textContent = sample.state;
  element('sandbox-yaw').textContent = sample.yaw;
  renderPlaybackEvents(sample.t);
}

function renderPlaybackEvents(time) {
  const list = element('playback-events');
  list.replaceChildren();
  const events = playback.events || playback.samples
    .filter((sample, index) => index === 0 || sample.state !== playback.samples[index - 1].state)
    .map((sample) => ({ t: sample.t, type: 'state', data: { to: sample.state } }));
  for (const event of events.filter((item) => item.t <= time && !['command', 'ack'].includes(item.type)).slice(-6)) {
    const line = document.createElement('li');
    line.textContent = `${event.t.toFixed(2)} s · ${event.type} · ${event.data?.to || event.data?.reason || event.data?.action || ''}`;
    list.append(line);
  }
}

element('sandbox-scenario').onchange = loadPlayback;
element('sandbox-play').onclick = () => {
  if (!playback?.samples?.length) return;
  playing = !playing;
  if (playing) {
    if (playbackIndex === playback.samples.length - 1) playbackIndex = 0;
    playbackClock = performance.now() - playback.samples[playbackIndex].t * 1000;
  }
  element('sandbox-play').textContent = playing ? 'Pause' : 'Play';
};
element('sandbox-reset').onclick = () => {
  playbackIndex = 0; playing = false;
  element('sandbox-play').textContent = 'Play';
  drawPlayback();
};
setInterval(() => {
  if (!playing || !playback) return;
  const elapsed = (performance.now() - playbackClock) / 1000;
  while (playbackIndex < playback.samples.length - 1 && playback.samples[playbackIndex + 1].t <= elapsed) playbackIndex++;
  if (playbackIndex === playback.samples.length - 1) {
    playing = false;
    element('sandbox-play').textContent = 'Play';
  }
  drawPlayback();
}, 50);

element('replay-file').onchange = async (event) => {
  try {
    const file = event.target.files[0];
    if (!file) return;
    const value = JSON.parse(await file.text());
    if (!Array.isArray(value.samples) || !value.samples.length) throw new Error('Use an exported replay JSON');
    playback = value; playbackIndex = 0; playing = false;
    element('sandbox-play').textContent = 'Play';
    drawPlayback();
  } catch (error) {
    element('sandbox-state').textContent = error.message;
  }
};

async function initializeScenes() {
  try {
    const response = await fetch('/api/scenarios');
    if (!response.ok) throw new Error('Unable to load scenes');
    const scenes = await response.json();
    for (const id of ['operator-scenario', 'sandbox-scenario']) {
      for (const scene of scenes) {
        const option = document.createElement('option');
        option.value = scene; option.textContent = displayName(scene);
        element(id).append(option);
      }
      element(id).value = 'moving';
    }
    await loadPlayback();
  } catch (error) {
    element('sandbox-state').textContent = error.message;
  }
}
initializeScenes();
