# HackPHS 2026 — Ball Drone

A small indoor quadcopter inside a lightweight protective cage, designed to survive low-energy contact and continue its mission.

Start with [docs/README.md](docs/README.md). The [project Google Doc](https://docs.google.com/document/d/1QrmGZfF8AJm1gQhVAsY_8FbZmaZgIQHXRB_zzldYWVA/edit) is the primary planning source.

The [simulation](simulation/README.md) is a separate Git clone of [WasimVorvoi/HackPHS](https://github.com/WasimVorvoi/HackPHS), stored in `simulation/`.

The simulation runs on the user's Mac. A Raspberry Pi 5 will run tracking, yaw calculations and the demo server, with browser access over its hotspot or a shared network. See [demo deployment](docs/04-software.md#demo-deployment).

Project folder: `/Users/devk/Documents/HackPHS26`.

Native operator app: `/Users/devk/Applications/Ball Drone.app`. [Mac and Pi desktop instructions](docs/14-desktop-app.md). The Pi can also run headlessly with the Mac app connected to its server; phones keep browser access.

The local folder now includes [runnable software](software/README.md), [firmware foundation](firmware/README.md), [startup/recovery guide](docs/12-demo-runbook.md), and [recorded software evidence](evidence/README.md). Start the Mac demo from software/ using `.venv/bin/python -m ball_demo.cli serve`, then open http://127.0.0.1:8080/. Hardware, Pi operation, flight performance and CAD fit remain unverified.
