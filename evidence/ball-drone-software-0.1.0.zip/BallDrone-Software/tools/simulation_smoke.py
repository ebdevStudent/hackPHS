import asyncio
import json
import platform
from pathlib import Path

from playwright.async_api import async_playwright


async def main():
    root = Path(__file__).resolve().parents[1]
    errors, sessions = [], []
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=['--enable-unsafe-swiftshader'])
        page = await browser.new_page(viewport={'width': 1280, 'height': 800})
        page.on('pageerror', lambda error: errors.append(str(error)))
        await page.goto('http://127.0.0.1:8765', wait_until='domcontentloaded')
        await page.wait_for_function('!!window.__game', timeout=30000)
        for name in ['industrial', 'rescue']:
            await page.evaluate('(name)=>window.__game.start(name)', name)
            await page.wait_for_function("window.__game.G.state==='play' && window.__game.G.missionId!==null")
            await page.keyboard.down('Space'); await page.wait_for_timeout(900); await page.keyboard.up('Space')
            await page.keyboard.down('w'); await page.wait_for_timeout(900); await page.keyboard.up('w')
            await page.keyboard.press('c'); await page.wait_for_timeout(600)
            state = await page.evaluate('({state:__game.G.state,scenario:__game.G.level.id,time:__game.G.time,targets:__game.G.targets.length,camera:__game.G.cam,mission:__game.G.missionId,canvasWidth:__game.renderer.domElement.width})')
            assert state['state'] == 'play' and state['scenario'] == name and state['time'] > .5 and state['targets'] == 5
            await page.screenshot(path=str(root / f'evidence/simulation-{name}.png'))
            sessions.append(state)
        await page.keyboard.press('Escape')
        assert await page.evaluate('__game.G.state') == 'paused'
        await page.keyboard.press('Escape')
        assert await page.evaluate('__game.G.state') == 'play'
        await browser.close()
    assert not errors, errors
    result = {'environment': platform.platform(), 'browser': 'Playwright Chromium, software WebGL',
              'simulation_commit': 'f472e4fcf0ed1e19141bcfb42f1afa4ac302e7e3', 'sessions': sessions,
              'page_errors': errors, 'pass': True, 'scope': 'Short playable smoke only; not a full mission completion or physical model validation'}
    (root / 'evidence/simulation-smoke.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__': asyncio.run(main())
