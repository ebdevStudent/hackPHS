"""Reproducible software/host-firmware verification with traceable, failure-preserving output."""
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
import stat
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOFTWARE = ROOT / 'software'
MODULE_FLOORS = {'control.py': 100, 'protocol.py': 95, 'engine.py': 95, 'bridge.py': 95,
                 'api.py': 95, 'desktop_backend.py': 95, 'serial_emulator.py': 90,
                 'sources.py': 100, 'vision.py': 100, 'desktop.py': 95}


@contextmanager
def visible_coverage_startup():
    """Python 3.13 skips UF_HIDDEN .pth files in this Mac's file-provider venv."""
    path = Path(importlib.metadata.distribution('coverage').locate_file('a1_coverage.pth'))
    info = {'path': str(path), 'temporarily_unhidden': False}
    original = None
    if sys.platform == 'darwin' and path.exists():
        flags = path.stat().st_flags
        if flags & stat.UF_HIDDEN:
            original = flags
            os.chflags(path, flags & ~stat.UF_HIDDEN)
            info['temporarily_unhidden'] = True
    try:
        yield info
    finally:
        if original is not None:
            current = path.stat().st_flags
            os.chflags(path, current | stat.UF_HIDDEN)


def fingerprint():
    files = {}
    for directory in ('software/ball_demo', 'software/tests', 'firmware', 'tools'):
        for path in (ROOT / directory).rglob('*'):
            relative = path.relative_to(ROOT)
            if not path.is_file() or any(part.startswith('build') or part in ('__pycache__', '.venv') for part in relative.parts): continue
            if path.suffix not in ('.py', '.c', '.h', '.toml', '.lock'): continue
            files[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
    for path in [SOFTWARE / 'pyproject.toml', *SOFTWARE.glob('requirements*.lock')]:
        files[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    digest = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {'sha256': digest, 'files': files}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', choices=('core', 'desktop'), default='desktop')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--min-coverage', type=float, default=95)
    parser.add_argument('--sanitizers', choices=('undefined', 'address,undefined'),
                        default='undefined' if sys.platform == 'darwin' else 'address,undefined')
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = (args.output or ROOT / 'evidence/verification' / stamp).resolve()
    if output.exists(): parser.error('Output must be a new directory; prior evidence is never overwritten')
    output.mkdir(parents=True)
    report = {'started_utc': datetime.now(timezone.utc).isoformat(), 'profile': args.profile,
              'environment': {'platform': platform.platform(), 'architecture': platform.machine(),
                              'python': sys.version, 'executable': sys.executable},
              'dependencies': {}, 'source_before': fingerprint(), 'checks': [],
              'limits': ['Synthetic/PTY/software only; no physical serial port or aircraft.',
                         'Offscreen Qt checks do not establish Pi display/device/performance behavior.',
                         'Coverage records executed paths, not correctness or flight readiness.',
                         'No packaged-app/endurance or browser rehearsal is implied by this run.']}
    started = time.monotonic()
    def check(name, passed, **data):
        report['checks'].append({'name': name, 'pass': bool(passed), **data})
        print(('PASS' if passed else 'FAIL') + ': ' + name, flush=True)
    try:
        required = ['pytest', 'pytest-cov', 'coverage', 'opencv-python-headless', 'fastapi', 'pyserial']
        if args.profile == 'desktop': required += ['PySide6-Essentials', 'shiboken6']
        for name in required: report['dependencies'][name] = importlib.metadata.version(name)
        check('required dependencies', True)
        with visible_coverage_startup() as startup, tempfile.TemporaryDirectory(prefix='ball-verify-') as runtime:
            report['coverage_startup'] = startup
            env = {**os.environ, 'QT_QPA_PLATFORM': 'offscreen', 'COVERAGE_FILE': str(Path(runtime) / '.coverage'),
                   # Resolve source packages before any installed copy even during
                   # Python's early .pth/coverage startup in subprocesses.
                   'PYTHONPATH': str(SOFTWARE) + (os.pathsep + os.environ['PYTHONPATH'] if os.environ.get('PYTHONPATH') else '')}
            coverage_config = SOFTWARE / 'pyproject.toml'
            if args.profile == 'core':
                coverage_config = Path(runtime) / 'core.coveragerc'
                coverage_config.write_text('[run]\nbranch = true\nparallel = true\nconcurrency = thread, multiprocessing\npatch = subprocess, _exit\nsigterm = true\nomit = */ball_demo/desktop.py\n')
            command = [sys.executable, '-m', 'pytest', 'tests', '-q', '--tb=short',
                       '--junitxml=' + str(output / 'junit.xml'), '--cov=ball_demo', '--cov-branch',
                       '--cov-config=' + str(coverage_config), '--cov-fail-under=' + str(args.min_coverage),
                       '--cov-report=term-missing', '--cov-report=json:' + str(output / 'coverage.json'),
                       '--cov-report=html:' + str(output / 'coverage-html')]
            if args.profile == 'core': command += ['--ignore=tests/test_desktop.py', '--ignore=tests/test_desktop_edges.py',
                                                  '--ignore=tests/test_desktop_robustness.py', '--ignore=tests/test_desktop_matrix.py']
            with (output / 'pytest.txt').open('w') as log:
                result = subprocess.run(command, cwd=SOFTWARE, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=240)
            check('pytest and coverage floor', result.returncode == 0, exit_code=result.returncode,
                  command=command, minimum_coverage=args.min_coverage, output='pytest.txt')
            tree = ET.parse(output / 'junit.xml')
            suites = list(tree.getroot().iter('testsuite'))
            counts = {key: sum(int(suite.attrib.get(key, 0)) for suite in suites)
                      for key in ('tests', 'failures', 'errors', 'skipped')}
            report['pytest'] = counts
            check('no silently skipped checks', counts['skipped'] == 0, **counts)
            coverage = json.loads((output / 'coverage.json').read_text())
            report['coverage'] = {'totals': coverage['totals'], 'files': {
                name: data['summary'] for name, data in coverage['files'].items()}}
            for module, minimum in MODULE_FLOORS.items():
                if args.profile == 'core' and module == 'desktop.py': continue
                entry = next(data for name, data in coverage['files'].items() if name.endswith('/' + module))
                actual = entry['summary']['percent_covered']
                check('coverage floor: ' + module, actual >= minimum, actual=actual, minimum=minimum)
            compiler = shutil.which('clang') or shutil.which('cc')
            if not compiler: raise RuntimeError('A host C compiler is required for portable firmware checks')
            report['compiler'] = subprocess.run([compiler, '--version'], capture_output=True, text=True, check=True).stdout
            binary = Path(runtime) / 'firmware-tests'
            compile_command = [compiler, '-std=c11', '-Wall', '-Wextra', '-Werror', '-pedantic',
                               '-fsanitize=' + args.sanitizers, '-fno-omit-frame-pointer',
                               str(ROOT / 'firmware/core.c'), str(ROOT / 'firmware/test_core.c'), '-o', str(binary)]
            with (output / 'firmware.txt').open('w') as log:
                built = subprocess.run(compile_command, stdout=log, stderr=subprocess.STDOUT, timeout=60)
                run_code = None
                if built.returncode == 0:
                    run = subprocess.run([str(binary)], stdout=log, stderr=subprocess.STDOUT, timeout=30)
                    run_code = run.returncode
            check('portable firmware sanitizers: ' + args.sanitizers, built.returncode == 0 and run_code == 0,
                  compile_exit=built.returncode, run_exit=run_code, command=compile_command, output='firmware.txt')
    except Exception as error:
        check('verification execution', False, error=type(error).__name__ + ': ' + str(error))
    report['source_after'] = fingerprint()
    check('tested sources unchanged during run', report['source_before'] == report['source_after'])
    report['duration_s'] = time.monotonic() - started
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    report['pass'] = bool(report['checks']) and all(item['pass'] for item in report['checks'])
    (output / 'report.json').write_text(json.dumps(report, indent=2))
    artifacts = {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS.json'}
    (output / 'SHA256SUMS.json').write_text(json.dumps(artifacts, indent=2))
    print(str(output / 'report.json'))
    return 0 if report['pass'] else 1


if __name__ == '__main__': raise SystemExit(main())
