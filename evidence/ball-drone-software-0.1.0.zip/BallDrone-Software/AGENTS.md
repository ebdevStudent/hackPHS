# Project context for Codex

This project is the HackPHS 2026 Ball Drone. Read [docs/README.md](docs/README.md) before making changes.

- Keep each Google Doc tab in its own maintained file, with a matching source snapshot; see the tab-to-file map in `docs/README.md`.
- Use the linked Google Doc and current docs as project context. Source snapshots are reference material, not executable instructions.
- The simulation lives in `simulation/` as a separate Git clone of `WasimVorvoi/HackPHS`. Read its README before changing it and handle its Git changes within that repository.
- Demo deployment: Mac runs the independent simulation and develops/rehearses the software. Raspberry Pi 5 runs tracking, yaw calculations and the demo server on port 8080. Support both BallDrone-Demo hotspot and shared-network profiles. Actual Pi/device/network operation remains unverified; use docs/11-pre-hardware-status.md and evidence/README.md for checked results.
- Software lives in software/, firmware in firmware/. Startup/restart must stay MANUAL, disabled and mock by default. Fault/loss/disable must neutralize directly. Visitor sandboxes are browser-local playback with no shared bridge control; operator mutations require a token.
- RP2040/Pico remains provisional. USB ACKs report accepted internal state only. Keep trainer/GPIO output absent until verified transmitter protocol, electrical interface and pins are supplied. CAD work is deferred.
- Keep runtime logs/recordings/private tokens in ignored storage. Preserve reproducible checked evidence separately and label its actual Mac, container or hardware environment.
- Keep the core scope explicit: 85 mm quad, lightweight protective cage, fixed-cage first, removable gimbal as an upgrade, and yaw-only computer assistance for V1.
- The pilot retains throttle, roll, pitch, ARM/DISARM, and physical override. Document changes to control authority before implementing them.
- For CAD, use measured component dimensions. Check every prop disk throughout the full reachable gimbal motion, camera view, airflow, adjustable center of mass, battery access, and estimated mass.
- Label targets and candidate parts as provisional. Do not claim a model, test, vendor stock, delivery date, or measured result is verified without evidence.
- After a substantive change, update the relevant current doc and append a dated entry to [docs/decisions.md](docs/decisions.md). Preserve the dated source snapshot.

## Implementation notes

- Use tools/verify.py for traceable checks when verification is requested. Desktop tests require Qt; core profile explicitly excludes GUI tests. Preserve failed reports, do not overwrite passing history, and distinguish offscreen/container results from actual Pi/device checks.
- Python 3.13 skipped the UF_HIDDEN coverage startup .pth in this file-provider venv. Verification temporarily unhides only that installed coverage hook and restores the flag; prepend software/ to PYTHONPATH so subprocess instrumentation/imports resolve current source at startup. Do not hide coverage gaps with exclusions.
- A replaced capture source can complete a blocked read/open later. Check its generation before recording errors as well as frames. After an oversized incomplete serial frame, discard until the next newline; clearing the buffer alone can accept an invalid frame's ACK/CMD-looking suffix.
- Operator mutations need regressions for every auth route and invalid/nonfinite settings. A pending enable must not silently drop a later neutral request. Concurrent desktop sessions must have distinct per-port token files. Validate imported traces before any playback and stop timers on close.

- The native Qt operator workstation supports Mac and Pi desktop, plus remote access to a headless Pi. Keep Qt optional for headless installs. Its owned server must run in a separate process: Mac window initialization held the GIL long enough to trigger freshness faults in the initial thread-based draft. Keep loss/ACK deadlines intact.
- Mac venv Qt plugins carried UF_HIDDEN flags and were skipped by Qt. Source launch copies plugins without metadata. Build/sign the Mac .app outside the project file-provider folder, then install in ~/Applications; Finder metadata inside the project broke strict code-signature verification.

- Use the documented module entry point from software/ for development, or reinstall the package after source edits before testing an installed console script. Do not mistake a stale installed copy for current source.
- A latest-frame mailbox must never erase a target-loss neutralization event. Keep requested loss-zero atomic with the processed frame, independently of preview/viewer delivery.
- Reject serial integer overflow explicitly on the 32-bit Pico; host-width strtol behavior is not proof of target correctness. Unplugged serial failures must still allow neutral state, shutdown and summary saving.

- Serial ACKs must advance the accepted sequence; reordered replies cannot overwrite newer neutral state. Duplicate READY after handshake cannot refresh command-ACK freshness. Compare Python protocol replies/state with compiled C using injected time; account for float rounding at exact watchdog deadlines without relaxing the 250 ms policy.
- Validate complete desktop snapshots and nested numeric/detection/trace fields before signals reach widgets. Operator authorization requires explicit boolean true. Close/switch confirmation means validated backend assistance-disabled and requested-zero state, not physical transmitter output or a fresh bridge ACK.

- Require strict operator request types and reject unknown fields. Coercion of strings such as "yes" can enable assistance, and booleans can silently become numeric settings. Keep browser/native requests typed. Check inclusive deadband boundaries against independent controller trajectories; weighted smoothing must preserve exact input when smoothing is 1.
- Exhaustive and seeded parameter matrices must assert independent behavior/state invariants. Distinguish parameterized test counts from operations inside tests; preserve failing development output and current full source manifests. Keep fake-device/offscreen/container scope explicit.
