# Provisional RP2040 / Pico bridge

Portable C parser/watchdog and a Pico USB CDC scaffold. **Compiled, not flashed or electrically verified.** No trainer output, GPIO waveform or channel mapping is implemented.

## Host checks (Mac or Linux)

```sh
cd /Users/devk/Documents/HackPHS26
mkdir -p firmware/build-host
clang -std=c11 -Wall -Wextra -Werror firmware/core.c firmware/test_core.c -o firmware/build-host/test_core
firmware/build-host/test_core
```

Checks include bounds, session reset, duplicate/invalid command rejection without watchdog refresh, disabled zero, and 32-bit timer rollover. Time is injected; no board or sleeps are needed.

## Pico SDK build

The recorded build uses **official Pico SDK 2.2.0**, commit `a1438dff1d38bd9c65dbd693f0e5db4b9ae91779`, and **Arm GNU Toolchain 14.3.Rel1** for Darwin ARM64, including newlib. Homebrew's `arm-none-eabi-gcc` formula alone lacked the C runtime needed here; the complete official Arm toolchain was downloaded instead.

```sh
export PICO_SDK_PATH=/Users/devk/.cache/ball-drone/pico-sdk
export PICO_TOOLCHAIN_PATH=/Users/devk/.cache/ball-drone/arm-gnu-toolchain-14.3.rel1-darwin-arm64-arm-none-eabi
cmake -S firmware -B firmware/build -DPICO_BOARD=pico
cmake --build firmware/build -j4
```

For a fresh machine, clone `https://github.com/raspberrypi/pico-sdk.git` at tag `2.2.0`, initialize `lib/tinyusb`, install a complete Arm GNU embedded toolchain and CMake, and set the two paths to their local locations. Build does not require a Pico.

The USB scaffold polls input, validates complete messages, updates the internal watchdog and replies with accepted state. Output writes have a short timeout so a missing USB reader does not indefinitely block the watchdog loop. Actual scheduling must be checked on a board.

[Protocol](PROTOCOL.md) · [compiled UF2](../evidence/firmware/ball_bridge.uf2) · [ELF](../evidence/firmware/ball_bridge.elf) · [recorded compiler/SDK](../evidence/firmware/toolchain.txt) · [build log](../evidence/pico-build.txt) · [host tests](../evidence/firmware-host-tests.txt).

Physical work remains: exact transmitter/trainer protocol, voltage levels, connector/pins, channel mapping, pilot override and measured latency. See the [arrival worksheet](../docs/13-hardware-arrival.md).

References: [official Pico SDK USB stdio](https://www.raspberrypi.com/documentation/pico-sdk/runtime.html), [official Arm toolchain](https://developer.arm.com/Tools%20and%20Software/GNU%20Toolchain).
