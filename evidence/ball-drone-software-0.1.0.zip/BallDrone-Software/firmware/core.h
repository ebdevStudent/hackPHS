#ifndef BALL_CORE_H
#define BALL_CORE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define BALL_MAX_FRAME 128
#define BALL_WATCHDOG_MS 250
typedef struct {
    char session[33];
    uint32_t seq, last_valid_ms;
    bool enabled, has_command;
    int yaw;
    bool watchdog_fault;
} ball_core;

void ball_init(ball_core *core);
void ball_tick(ball_core *core, uint32_t now_ms);
/* Complete ASCII line only; reply describes internal accepted state, never GPIO output. */
bool ball_receive(ball_core *core, const char *line, size_t length, uint32_t now_ms,
                  char *reply, size_t capacity);
#endif
