#include "core.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ball_init(ball_core *core) { memset(core, 0, sizeof(*core)); }
void ball_tick(ball_core *core, uint32_t now_ms) {
    if (core->has_command && (uint32_t)(now_ms - core->last_valid_ms) >= BALL_WATCHDOG_MS) {
        core->enabled = false;
        core->yaw = 0;
        core->watchdog_fault = true;
    }
}
static bool session_valid(const char *s) {
    size_t n = strlen(s);
    if (!n || n > 32) return false;
    for (size_t i = 0; i < n; ++i)
        if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-') return false;
    return true;
}
static bool integer(const char *s, long minimum, long maximum, long *value) {
    const char *p = s;
    bool negative = *p == '-';
    if (negative) ++p;
    if (!*p) return false;
    if (p[0] == '0' && p[1]) return false;
    if (negative && (minimum >= 0 || !strcmp(p, "0"))) return false;
    unsigned long limit = (unsigned long)(negative ? -minimum : maximum);
    unsigned long number = 0;
    for (; *p; ++p) {
        if (*p < '0' || *p > '9') return false;
        unsigned long digit = (unsigned long)(*p - '0');
        if (number > limit / 10 || (number == limit / 10 && digit > limit % 10)) return false;
        number = number * 10 + digit;
    }
    *value = negative ? -(long)number : (long)number;
    return *value >= minimum && *value <= maximum;
}
bool ball_receive(ball_core *core, const char *line, size_t length, uint32_t now_ms,
                  char *reply, size_t capacity) {
    ball_tick(core, now_ms);
    if (!length || length > BALL_MAX_FRAME) return false;
    char buffer[BALL_MAX_FRAME + 1];
    for (size_t i = 0; i < length; ++i) {
        unsigned char c = (unsigned char)line[i];
        if (!c || c > 127) return false;
        buffer[i] = (char)c;
    }
    while (length && (buffer[length-1] == '\n' || buffer[length-1] == '\r')) --length;
    buffer[length] = 0;
    char *fields[7];
    size_t count = 1;
    fields[0] = buffer;
    for (size_t i = 0; i < length; ++i) {
        if (buffer[i] == ' ') {
            if (count == 7 || i == 0 || i+1 == length || buffer[i+1] == ' ') return false;
            buffer[i] = 0;
            fields[count++] = &buffer[i+1];
        } else if ((unsigned char)buffer[i] < 33) return false;
    }
    if (count < 3 || strcmp(fields[1], "1") || !session_valid(fields[2])) return false;
    if (!strcmp(fields[0], "HELLO") && count == 3) {
        ball_init(core);
        strcpy(core->session, fields[2]);
        snprintf(reply, capacity, "READY 1 %s NO_OUTPUT\n", core->session);
        return true;
    }
    if (strcmp(fields[0], "CMD") || count != 6 || !core->session[0] || strcmp(core->session, fields[2])) return false;
    long seq, yaw;
    if (!integer(fields[3], 1, 2147483647, &seq) || fields[3][0] == '-' ||
        (strcmp(fields[4], "0") && strcmp(fields[4], "1")) || !integer(fields[5], -1000, 1000, &yaw)) return false;
    bool enabled = fields[4][0] == '1';
    if (!enabled && yaw != 0) return false;
    const char *fault = "NONE";
    if ((uint32_t)seq <= core->seq) {
        fault = "SEQUENCE";
    } else {
        core->seq = (uint32_t)seq;
        core->enabled = enabled;
        core->yaw = (int)yaw;
        core->last_valid_ms = now_ms;
        core->has_command = true;
        core->watchdog_fault = false;
    }
    snprintf(reply, capacity, "ACK 1 %s %ld %d %d %s\n", core->session, seq,
             core->enabled ? 1 : 0, core->yaw, fault);
    return true;
}
