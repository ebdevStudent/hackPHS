#!/usr/bin/env bash
set -euo pipefail
device=${BALL_WIFI_DEVICE:-wlan0}
active_ip=$(nmcli -g IP4.ADDRESS device show "$device" | head -n 1 | cut -d/ -f1)
active_network=$(nmcli -g GENERAL.CONNECTION device show "$device")
[[ -n "$active_ip" ]] || { echo 'No active IPv4 address on the selected adapter'; exit 1; }
python_bin=${BALL_PYTHON:-/opt/ball-drone/software/.venv/bin/python}
output_dir=${1:-./connection-card}
"$python_bin" -m ball_demo.cli connection-card --url "http://$active_ip:8080/" --network "$active_network" --output "$output_dir"
