# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['/Users/devk/Documents/HackPHS26/software/desktop/launch.py'],
    pathex=['/Users/devk/Documents/HackPHS26/software'],
    binaries=[],
    datas=[('/Users/devk/Documents/HackPHS26/software/ball_demo/static', 'ball_demo/static')],
    hiddenimports=['uvicorn.logging', 'uvicorn.loops.asyncio', 'uvicorn.protocols.http.h11_impl', 'uvicorn.lifespan.on'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['playwright', 'pytest', 'tkinter', 'PySide6.QtQml', 'PySide6.QtQuick', 'PySide6.QtWebEngineCore'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Ball Drone',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch='arm64',
    codesign_identity=None,
    entitlements_file=None,
    icon=['/Users/devk/Documents/HackPHS26/software/desktop/BallDrone.icns'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Ball Drone',
)
app = BUNDLE(
    coll,
    name='Ball Drone.app',
    icon='/Users/devk/Documents/HackPHS26/software/desktop/BallDrone.icns',
    bundle_identifier='org.hackphs.ball-drone',
)
