# refs — references and evidence

Source: Google Doc **refs** tab, read 2026-10-04. [Preserved tab text](sources/google-doc-2026-10-04/07-refs.md). Current user decisions are recorded in [decisions.md](decisions.md).

## References

- [Project Google Doc](https://docs.google.com/document/d/1QrmGZfF8AJm1gQhVAsY_8FbZmaZgIQHXRB_zzldYWVA/edit): original planning source; [separate tab snapshots](sources/google-doc-2026-10-04/README.md) are preserved locally.
- [Thingiverse 408519](https://www.thingiverse.com/thing:408519): cage/CAD reference named by the source; geometry and license have not been inspected here.
- [BOM](02-bom.md): purchasing candidates and links to the supplied vendor references. Availability and delivery must be rechecked.
- [WasimVorvoi/HackPHS](https://github.com/WasimVorvoi/HackPHS): imported simulation repository, commit `f472e4fcf0ed1e19141bcfb42f1afa4ac302e7e3`. Local [run instructions](../simulation/README.md).

## Evidence to retain

Save manufacturer/vendor pages or dated screenshots for specifications presented to judges. Save project-generated evidence for mass/thrust budgets, battery endurance, latency/override, contacts, and completed demo rehearsals.

Keep sources and measured results distinguishable. Label each artifact with its origin, date, configuration, and verification status, then link it from the relevant current doc and decision entry.
